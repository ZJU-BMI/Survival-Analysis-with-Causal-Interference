import numpy as np
import matplotlib.pyplot as plt
import os
import pandas as pd

model_name = 'fg'

titles_seer = ['Breast Cancer', 'Cardiovascular Disease', 'Cerebrovascular Disease']

result_path = 'shap_meanabs_result/seer'

if not os.path.exists(result_path):
    os.makedirs(result_path)

shap_values_causal = np.load('shap_data/seer_fg/shap_value_seer_causal.npy')
shap_values_origin = np.load('shap_data/seer_fg/shap_value_seer.npy')

shap_val_mean_casual = np.mean(np.abs(shap_values_causal), axis=0)
shap_val_mean_origin = np.mean(np.abs(shap_values_origin), axis=0)

xaxis = np.array([
    [0, 0.01, 0.02, 0.03],
    [0, 0.0004, 0.0008, 0.0012],
    [0, 0.00004, 0.00008, 0.00012],
])
features_name = ['age', 'gender', 'income_level', 'grade',
                 'rx_prim_site', 'cs_tumor_size', 'cs_extension', 'cs_lymph_nodes',
                 'first_mailg', 'total_mailg', 'derived_ajcc_stage', 'nodes_examed',
                 'nodes_positive', 'ethnicity_Black', 'ethnicity_White',
                 'ethnicity_other', 'prim_site-Nipple',
                 'prim_site-Central', 'prim_site-Upper-inner', 'prim_site-Lower-inner',
                 'prim_site-Upper-outer', 'prim_site-Lower-outer', 'prim_site-Axillarytail',
                 'prim_site-Overlapping', 'prim_site-NOS', 'laterality_Bilateral-single',
                 'laterality_Left', 'laterality_one-side', 'laterality_Paired-site', 'laterality_Right',
                 'hist_behavior-8480', 'hist_behavior_8500', 'hist_behavior_8520', 'hist_behavior_8522',
                 'hist_behavior_8523', 'hist_behavior_other', 'cs_mets_at_dx_0', 'cs_mets_at_dx_5',
                 'cs_mets_at_dx_10', 'cs_mets_at_dx_40', 'cs_mets_at_dx_42','cs_mets_at_dx_44',
                 'cs_mets_at_dx_50', 'cs_mets_at_dx_60', 'summary_stage_Distant', 'summary_stage_Localized',
                 'summary_stage_Regional']
features_name = np.asarray(features_name)


for i in range(3):
    fig = plt.figure(figsize=(20, 40))
    ax = fig.add_subplot(111)
    shap_causal = shap_val_mean_casual[:, i]
    shap_origin = shap_val_mean_origin[:, i]
    shap_causal = shap_causal
    shap_origin = shap_origin
    # order by absolute shap value DESC
    order = np.argsort(shap_causal)
    shap_display_cau = shap_causal[order]
    shap_display_ori = shap_origin[order]

    print('------------------------------------------------------------')
    features_display = features_name[order]

    height = 0.4
    a1 = list(range(len(features_display)))
    a2 = [i + height for i in a1]

    plt.barh(a2, shap_display_cau, height=height, label='Fine-Gray + Causal', color='#f95e47')

    plt.barh(range(len(features_display)), shap_display_ori, height=height,
             label='Fine-Gray', color='#2191b3')

    plt.yticks(a2, features_display)

    plt.tick_params(labelsize=40)

    ax.set_xlabel('mean(|SHAP value|)', fontsize=45)
    ax.set_ylabel('Features', fontsize=45)

    y_num = np.arange(len(features_display))
    plt.ylim(min(y_num) - 1, max(y_num) + 1)

    plt.title(titles_seer[i], fontsize=50)
    plt.tight_layout(h_pad=5, w_pad=4)
    plt.legend(fontsize=30, loc='lower right')
    plt.xticks(xaxis[i, :])
    plt.savefig(result_path + '/shap_meanabs_seer{}.png'.format(i + 1))
    plt.show()
