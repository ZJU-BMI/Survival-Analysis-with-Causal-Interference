# install nricens package first
# install.packages("nricens")
library(survival)
library(nricens)

risk_casual <- read.csv('nri_data/fg_mimic/fg_risk_causal.csv')
risk_origin <- read.csv('nri_data/fg_mimic/fg_risk_origin.csv')
km_risk <- read.csv('nri_data/fg_mimic/risk_mimic.csv')
df <- read.csv('nri_data/fg_mimic/true_label.csv')
true_time <- df$true_time

t0 = 5 # 5 20 60
cuts <- as.numeric(km_risk[t0 + 1, 2:12])

ev <- 1
thres <- cuts[ev]
true_label <- ifelse(df$true_label == ev, 1, 0)

fit <- nricens(time = true_time, event = true_label,
               p.std = risk_origin[, ev],
               p.new = risk_casual[, ev], cut = thres, t0 = t0)

