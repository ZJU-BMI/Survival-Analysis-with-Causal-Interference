import numpy as np
import matplotlib.pyplot as plt
import os
import pandas as pd

model_name = 'fg'

titles_mimic = ['Septicemia/Sepsis', 'Cerebral Hemorrhage', 'Acute Respiratory Failure',
                'Myocardial Infarction', 'Heart Failure', 'Pneumonia', 'Cerebral Infarction',
                'Subarachnoid Hemorrhage', 'Neoplasm of Bronchus or Lung',
                'Cirrhosis of Liver', 'Acute Kidney Failure']

result_path = 'shap_meanabs_result/mimic'

if not os.path.exists(result_path):
    os.makedirs(result_path)


shap_values_causal = np.load('shap_data/mimic_fg/shap_value_mimic_causal.npy')
shap_values_origin = np.load('shap_data/mimic_fg/shap_value_mimic.npy')

shap_val_mean_casual = np.mean(np.abs(shap_values_causal), axis=0)
shap_val_mean_origin = np.mean(np.abs(shap_values_origin), axis=0)


features_name = ['ca', 'leu', 'hepf', 'panc', 'vt', 'diab', 'gender', 'age', 'height', 'weight',
                 'bmi', 'heart_rate', 'sbp', 'dbp', 'mbp', 'fio2', 'resp_rate', 'temperature',
                 'spo2', 'hct', 'hgb', 'mch', 'mchc', 'mcv', 'platelet', 'rbc', 'rdw', 'wbc', 'pco2',
                 'po2', 'tco2', 'base_excess', 'aniongap', 'bicarbonate', 'bun', 'calcium',
                 'chloride', 'glucose', 'sodium', 'potassium', 'magnesium', 'phosphate',
                 'lactate', 'ph', 'inr', 'pt', 'ptt', 'alt', 'alp', 'ast', 'bil_total', 'nacl_09',
                 'dextrose', 'propofol', 'norepinephrine', 'gastric_med', 'insulin', 'gt_flush',
                 'fentanyl', 'kcl', 'heparin_sodium', 'vancomycin', 'furosemide',
                 'INDIAN', 'ASIAN', 'BLACK', 'HISPANIC/LATINO',
                 'ethnicity_OTHER', 'WHITE']
features_name = np.asarray(features_name)


for i in range(11):
    fig = plt.figure(figsize=(20, 40))
    ax = fig.add_subplot(111)
    shap_causal = shap_val_mean_casual[:, i]
    shap_origin = shap_val_mean_origin[:, i]

    # order by absolute shap value DESC
    order = np.argsort(shap_causal)

    print(shap_causal[order])
    shap_display_cau = shap_causal[order]
    shap_display_ori = shap_origin[order]

    print('------------------------------------------------------------')
    features_display = features_name[order]

    height = 0.4
    a1 = list(range(len(features_display)))
    a2 = [i + height for i in a1]
    plt.barh(a2, shap_display_cau, height=height, label='Fine-Gray + Causal', color='#f95e47')

    plt.barh(range(len(features_display)), shap_display_ori, height=height,
             label='Fine-Gray', color='#2191b3')

    plt.yticks(a2, features_display)

    plt.tick_params(labelsize=40)

    ax.set_xlabel('mean(|SHAP value|)', fontsize=45)
    ax.set_ylabel('Features', fontsize=45)

    y_num = np.arange(len(features_display))
    plt.ylim(min(y_num) - 1, max(y_num) + 1)

    plt.title(titles_mimic[i], fontsize=50)
    plt.tight_layout(h_pad=5, w_pad=4)
    plt.legend(fontsize=30, loc='lower right')
    plt.xticks([0, 0.005, 0.01, 0.015])
    # plt.legend(fontsize=50, bbox_to_anchor=(-3.8, -0.15), loc=3, borderaxespad=0,
    #              ncol=2, frameon=False)
    plt.savefig(result_path + '/shap_meanabs_mimic{}.png'.format(i + 1))
    plt.show()
