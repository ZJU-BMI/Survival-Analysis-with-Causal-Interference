import numpy as np
from utils import cal_net_benefit
import pandas as pd
import matplotlib.pyplot as plt


title = {
    'dh': 'DeepHit',
    'cscox': 'cs-Cox',
    'fg': 'Fine-Gray',
    'ddh': 'Dynamic-DeepHit',
    'dsm': 'DSM'
}

model_name = 'ddh'
titles_eicu = ['Cardiac Arrest', 'Sepsis', 'Acute Respiratory Failure', 'Septic Shock',
               'Stroke', 'Pneumonia', 'GI Bleeding', 'Heart Failure','Acute Respiratory Distress',
               'Myocardial Infarction', 'Acute Renal Failure']

dca_path = 'dca_data/eicu_{}'.format(model_name)
risk_causal = np.load(dca_path + '/dca_causal.npy')
risk_origin = np.load(dca_path + '/dca_origin.npy')
true_labels = pd.read_csv('dca_data/eicu_{}/true_label.csv'.format(model_name))

if model_name == 'fg':
    ymax = [
        0.1, 0.08, 0.02, 0.03,
        0.015, 0.01, 0.01, 0.008,
        0.005, 0.008, 0.006
    ]
    ymin = [
        -0.01, -0.01, -0.002, -0.005,
        -0.001, -0.001, -0.001, -0.001,
        -0.0005, -0.0005, -0.0005,
    ]
    xmax = [
        1, 0.6, 0.2, 0.5,
        0.6, 0.2, 0.3, 0.2,
        0.3, 0.15, 0.05
    ]
elif model_name == 'cscox':
    ymax = [
        0.09, 0.08, 0.025, 0.03,
        0.015, 0.01, 0.01, 0.008,
        0.005, 0.008, 0.005
    ]
    ymin = [
        -0.01, -0.01, -0.002, -0.005,
        -0.001, -0.001, -0.001, -0.001,
        -0.0005, -0.0005, -0.0005,
    ]
    xmax = [
        1, 0.5, 0.2, 0.5,
        0.4, 0.2, 0.3, 0.15,
        0.3, 0.15, 0.05
    ]
elif model_name == 'dsm':
    ymax = [
        0.09, 0.08, 0.03, 0.04,
        0.02, 0.015, 0.01, 0.01,
        0.005, 0.008, 0.006
    ]
    ymin = [
        -0.01, -0.01, -0.002, -0.005,
        -0.001, -0.001, -0.001, -0.001,
        -0.0005, -0.001, -0.0005,
    ]
    xmax = [
        0.6, 0.3, 0.2, 0.4,
        0.3, 0.15, 0.4, 0.15,
        0.2, 0.2, 0.1
    ]
elif model_name == 'dh':
    ymax = [
        0.1, 0.08, 0.03, 0.04,
        0.01, 0.015, 0.01, 0.01,
        0.005, 0.008, 0.006
    ]
    ymin = [
        -0.01, -0.01, -0.002, -0.005,
        -0.001, -0.001, -0.001, -0.001,
        -0.0005, -0.001, -0.0005,
    ]
    xmax = [
        0.6, 0.5, 0.3, 0.4,
        0.3, 0.1, 0.1, 0.25,
        0.05, 0.05, 0.05
    ]
elif model_name == 'ddh':
    ymax = [
        0.1, 0.08, 0.04, 0.04,
        0.02, 0.01, 0.01, 0.01,
        0.008, 0.008, 0.005
    ]
    ymin = [
        -0.01, -0.01, -0.005, -0.005,
        -0.002, -0.001, -0.001, -0.001,
        -0.001, -0.001, -0.0005,
    ]
    xmax = [
        0.8, 0.4, 0.15, 0.25,
        0.4, 0.1, 0.2, 0.1,
        0.1, 0.15, 0.05
    ]
else:
    ymax = [
        0.1, 0.08, 0.04, 0.04,
        0.02, 0.01, 0.01, 0.01,
        0.008, 0.008, 0.005
    ]
    ymin = [
        -0.01, -0.01, -0.005, -0.005,
        -0.002, -0.001, -0.001, -0.001,
        -0.001, -0.001, -0.0005,
    ]
    xmax = [
        0.8, 0.4, 0.15, 0.25,
        0.4, 0.1, 0.2, 0.1,
        0.1, 0.15, 0.05
    ]

time = np.asarray(true_labels['true_time'])
label = np.asarray(true_labels['true_label'])


fig = plt.figure(figsize=(45, 30))
for ev in range(11):
    print(ev + 1)
    label_ev = np.cast['int32'](label == ev + 1)
    thresholds = np.arange(0, xmax[ev] + 0.01, 0.01)
    net_benefit_causal = np.zeros([len(thresholds)])
    net_benefit_origin = np.zeros([len(thresholds)])
    net_benefit_alltreat = np.zeros([len(thresholds)])

    for i, thres in enumerate(thresholds):
        net_benefit_causal[i] = cal_net_benefit(time, label_ev, thres, risk_causal[:, ev], 20)
        net_benefit_origin[i] = cal_net_benefit(time, label_ev, thres, risk_origin[:, ev], 20)
        net_benefit_alltreat[i] = cal_net_benefit(time, label_ev, thres, np.ones(len(time)), 20)

    ax = fig.add_subplot(3, 4, ev + 1)
    plt.tick_params(labelsize=30)
    plt.plot(thresholds, net_benefit_alltreat, label='ALL',
             color='black', ls='--', lw=3)
    plt.plot(thresholds, np.zeros(len(thresholds)), ls='--', lw=3, color='gray', label='None')
    plt.plot(thresholds, net_benefit_causal, label='{} + Causal'.format(title[model_name]),
             color='#cb5362', lw=5)
    plt.plot(thresholds, net_benefit_origin, label='{}'.format(title[model_name]),
             color='#3fadaf', lw=5)

    ax.set_xlabel('Threshold Prob.', fontsize=35)
    ax.set_ylabel('Net Benefit', fontsize=35)
    ax.set_xlim(0, xmax[ev])
    ax.set_ylim(ymin[ev], ymax[ev])
    plt.title(titles_eicu[ev], fontsize=45)

    plt.tight_layout(h_pad=5, w_pad=4)

plt.legend(fontsize=42, bbox_to_anchor=(1.2, 0), loc=3,
           borderaxespad=0, frameon=False)
plt.savefig('dca_data/dcaplot_eicu_{}.png'.format(model_name))
plt.show()
