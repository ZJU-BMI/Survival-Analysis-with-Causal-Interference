import os

import numpy as np
from utils import cal_net_benefit
import pandas as pd


title = {
    'dh': 'DeepHit',
    'cscox': 'cs-Cox',
    'dsm': 'DSM',
    'fg': 'Fine-Gray',
    'ddh': 'Dynamic-DeepHit'
}
model_name = 'dsm'
titles_eicu = ['Cardiac Arrest', 'Sepsis', 'Acute Respiratory Failure', 'Septic Shock',
               'Stroke', 'Pneumonia', 'GI Bleeding', 'Heart Failure','Acute Respiratory Distress',
               'Myocardial Infarction', 'Acute Renal Failure']

dca_path = 'dca_data/eicu_{}'.format(model_name)
risk_causal = np.load(dca_path + '/dca_causal.npy')
risk_origin = np.load(dca_path + '/dca_origin.npy')
true_labels = pd.read_csv('dca_data/mimic_{}/true_label.csv'.format(model_name))


time = np.asarray(true_labels['true_time'])
label = np.asarray(true_labels['true_label'])


thresmax = [30, 18, 6, 18, 12, 6, 6, 6, 6, 6, 6]
step = [i / 6 for i in thresmax]

for ev in range(11):
    print('ev:' + titles_eicu[ev])
    label_ev = np.cast['int32'](label == ev + 1)
    thresholds = np.arange(step[ev], thresmax[ev] + 1, step[ev]) / 100
    net_benefit_causal = np.zeros([len(thresholds)])
    net_benefit_origin = np.zeros([len(thresholds)])
    net_benefit_alltreat = np.zeros([len(thresholds)])

    for i, thres in enumerate(thresholds):
        net_benefit_causal[i] = cal_net_benefit(time, label_ev, thres, risk_causal[:, ev], 20)
        net_benefit_origin[i] = cal_net_benefit(time, label_ev, thres, risk_origin[:, ev], 20)
        net_benefit_alltreat[i] = cal_net_benefit(time, label_ev, thres, np.ones(len(time)), 20)

    res_path = 'dca_result/eicu_net_benefit_{}/'.format(model_name)
    if not os.path.exists(res_path):
        os.makedirs(res_path)
    res_df = pd.DataFrame({
        'threshold': thresholds,
        'nb_origin': np.round(net_benefit_origin * 100, 2),
        'nb_causal': np.round(net_benefit_causal * 100, 2),
        'nb_origin_all': np.round((net_benefit_origin - net_benefit_alltreat) * 100, 2),
        'nb_casual_all': np.round((net_benefit_causal - net_benefit_alltreat) * 100, 2)
    })
    res_df.to_csv(res_path + '/net_benefit_mimic_ev{}.csv'.format(ev + 1))
