import numpy as np
import matplotlib.pyplot as plt
import os

import pandas as pd

titles_eicu = ['Cardiac Arrest', 'Sepsis', 'Acute Respiratory Failure', 'Septic Shock',
               'Stroke', 'Pneumonia', 'GI Bleeding', 'Heart Failure',
               'Acute Respiratory Distress', 'Myocardial Infarction', 'Acute Renal Failure']

result_path = 'shap_meanabs_result/eicu'

if not os.path.exists(result_path):
    os.makedirs(result_path)

shap_values_causal = np.load('shap_data/eicu_fg/shap_value_eicu_causal.npy')
shap_values_origin = np.load('shap_data/eicu_fg/shap_value_eicu.npy')


shap_val_mean_casual = np.mean(np.abs(shap_values_causal), axis=0)
shap_val_mean_origin = np.mean(np.abs(shap_values_origin), axis=0)

features_name = ['ra', 'respa', 'suhe','copd', 'vt', 'pe', 'age', 'gender', 'weight', 'height', 'bmi',
                 'heart_rate', 'resp_rate', 'sao2', 'sbp', 'dbp', 'mbp', 'temperature',
                 'gcs_total', 'hgb', 'hct', 'mch', 'mchc', 'mcv', 'mpv', 'platelets',
                 'rbc', 'rdw', 'wbc', 'lymp', 'mono', 'albumin', 'total_protein',
                 'aniongap', 'bicarbonate', 'bun', 'calcium', 'chloride', 'creatinine',
                 'glucose', 'sodium', 'potassium', 'magnesium', 'alt', 'bil_total',
                 'ethnicity_African American', 'ethnicity_Asian', 'ethnicity_Caucasian',
                 'ethnicity_Hispanic', 'ethnicity_Native American', 'ethnicity_OTHER']


features_name = np.asarray(features_name)


for i in range(11):
    fig = plt.figure(figsize=(20, 40))
    ax = fig.add_subplot(111)
    shap_causal = shap_val_mean_casual[:, i]
    shap_origin = shap_val_mean_origin[:, i]
    # order by absolute shap value DESC
    order = np.argsort(shap_causal)

    shap_display_cau = shap_causal[order]
    shap_display_ori = shap_origin[order]
    print("event: " + str(i + 1))

    print('------------------------------------------------------------')
    features_display = features_name[order]

    height = 0.4
    a1 = list(range(len(features_display)))
    a2 = [i + height for i in a1]
    plt.barh(a2, shap_display_cau, height=height, label='Fine-Gray + Causal', color='#f95e47')
    # plt.barh(a2, shap_display_ori, height=height, label='FG', color='blue')
    plt.barh(range(len(features_display)), shap_display_ori, height=height,
             label='Fine-Gray', color='#2191b3')

    plt.yticks(a2, features_display)

    plt.tick_params(labelsize=40)

    ax.set_xlabel('mean(|SHAP value|)', fontsize=45)
    ax.set_ylabel('Features', fontsize=45)

    y_num = np.arange(len(features_display))
    plt.ylim(min(y_num) - 1, max(y_num) + 1)

    plt.title(titles_eicu[i], fontsize=50)
    plt.tight_layout(h_pad=5, w_pad=4)
    plt.legend(fontsize=30, loc='lower right')
    plt.savefig(result_path + '/shap_meanabs_eicu{}.png'.format(i + 1))
    plt.show()


