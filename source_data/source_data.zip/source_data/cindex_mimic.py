import numpy as np
import pandas as pd
from KMEstimate import *
import matplotlib.pyplot as plt

titles_mimic = ['Septicemia/Sepsis', 'Cerebral Hemorrhage', 'Acute Respiratory Failure',
                'Myocardial Infarction', 'Heart Failure', 'Pneumonia', 'Cerebral Infarction',
                'Subarachnoid Hemorrhage', 'Neoplasm of Bronchus or Lung', 'Cirrhosis of Liver', 'Acute Kidney Failure']

result_path_fg = 'cindex_data/mimic_fg'
fg_causal = pd.read_csv(result_path_fg + '/cindex_causal_11.csv')
fg_origin = pd.read_csv(result_path_fg + '/cindex_origin_11.csv')

result_path_cscox = 'cindex_data/mimic_cscox'
cscox_causal = pd.read_csv(result_path_cscox + '/cindex_causal_11.csv')
cscox_origin = pd.read_csv(result_path_cscox + '/cindex_origin_11.csv')

result_path_dsm = 'cindex_data/mimic_dsm'
dsm_causal = pd.read_csv(result_path_dsm + '/cindex_causal_11.csv')
dsm_origin = pd.read_csv(result_path_dsm + '/cindex_origin_11.csv')

result_path_dh = 'cindex_data/mimic_dh'
dh_causal = pd.read_csv(result_path_dh + '/cindex_causal_11.csv')
dh_origin = pd.read_csv(result_path_dh + '/cindex_origin_11.csv')

result_path_ddh = 'cindex_data/mimic_ddh'
ddh_causal = pd.read_csv(result_path_ddh + '/cindex_causal_11.csv')
ddh_origin = pd.read_csv(result_path_ddh + '/cindex_origin_11.csv')


times = [5, 25, 50, 75]
fig = plt.figure(figsize=(42, 30))
# fig = plt.figure(figsize=(12, 10))
fsize = 45
mksize = 18
lwidth = 4
# fsize = 35
# mksize = 18
# lwidth = 4

ymin = [0.6, 0.7, 0.6, 0.75,
        0.65, 0.55, 0.6, 0.6,
        0.6, 0.75, 0.5]

ymax = [1, 1, 1, 1,
        1.0, 1.0, 1.0, 1.0,
        1, 1.0, 1]

cindex_casual_fg = np.asarray(fg_causal)
cindex_origin_fg = np.asarray(fg_origin)

cindex_casual_cscox = np.asarray(cscox_causal)
cindex_origin_cscox = np.asarray(cscox_origin)

cindex_casual_dsm = np.asarray(dsm_causal)
cindex_origin_dsm = np.asarray(dsm_origin)

cindex_casual_dh = np.asarray(dh_causal)
cindex_origin_dh = np.asarray(dh_origin)

cindex_casual_ddh = np.asarray(ddh_causal)
cindex_origin_ddh = np.asarray(ddh_origin)

for ev in range(11):
    ax = fig.add_subplot(3, 4, ev + 1)
    # Plotting c-index result
    # colors
    # 3232b6
    # e35f34
    # de0800
    # 5b92d9
    # feaa11
    # f05066

    # 307724
    # 6ea84e

    # 8666c9
    # c45ca2
    plt.plot(times, cindex_casual_fg[:, ev], label='Fine-Gray + Causal',
             color='#3232b6', lw=lwidth, marker='o', markersize=mksize)

    plt.plot(times, cindex_casual_cscox[:, ev], label='cs-Cox + Causal',
             color='#307724', lw=lwidth, marker='o', markersize=mksize)

    plt.plot(times, cindex_casual_dsm[:, ev], label='DSM + Causal',
             color='#8666c9', lw=lwidth, marker='o', markersize=mksize)

    plt.plot(times, cindex_casual_dh[:, ev], label='DeepHit + Causal',
             color='#e35f34', lw=lwidth, marker='o', markersize=mksize)

    plt.plot(times, cindex_casual_ddh[:, ev], label='Dynamic-DeepHit + Causal',
             color='#de0800', lw=4, marker='o', markersize=mksize)

    plt.plot(times, cindex_origin_fg[:, ev], label='Fine-Gray',
             color='#5b92d9', lw=lwidth, marker='D', linestyle='--', markersize=mksize)

    plt.plot(times, cindex_origin_cscox[:, ev], label='cs-Cox',
             color='#6ea84e', lw=lwidth, marker='D', linestyle='--', markersize=mksize)

    plt.plot(times, cindex_origin_dsm[:, ev], label='DSM',
             color='#c45ca2', lw=lwidth, marker='D', linestyle='--', markersize=mksize)

    plt.plot(times, cindex_origin_dh[:, ev], label='DeepHit',
             color='#feaa11', lw=lwidth, marker='D', linestyle='--', markersize=mksize)

    plt.plot(times, cindex_origin_ddh[:, ev], label='Dynamic-DeepHit',
             color='#f05066', lw=lwidth, marker='D', linestyle='--', markersize=mksize)

    plt.grid(linestyle='-.')
    plt.tick_params(labelsize=fsize)

    ax.set_xlabel('Time Horizon (days)', fontsize=fsize)
    ax.set_ylabel('C-Index C(t)', fontsize=fsize)
    ax.set_ylim([ymin[ev], ymax[ev]])
    ax.set_xlim([0, 80])
    plt.xticks([5, 25, 50, 75])

    # plt.title(titles_mimic[ev], fontsize=45)
    plt.tight_layout(h_pad=5, w_pad=4)


plt.legend(fontsize=35, bbox_to_anchor=(1.3, 0.), loc=3,
           borderaxespad=0, ncol=1, frameon=False)

# plt.legend(fontsize=45, bbox_to_anchor=(-2.4, -0.5), loc=3,
#            borderaxespad=0, ncol=3, frameon=False)

plt.savefig('cindex_data/mimic_cindex_test.png')
plt.show()
