import numpy as np
import pandas as pd
from KMEstimate import *
import matplotlib.pyplot as plt

titles_seer = ['Breast Cancer', 'Cardiovascular Disease', 'Cerebrovascular Disease']

result_path_fg = 'cindex_data/seer_fg'
fg_causal = pd.read_csv(result_path_fg + '/cindex_causal.csv')
fg_origin = pd.read_csv(result_path_fg + '/cindex_origin.csv')

result_path_cscox = 'cindex_data/seer_cscox'
cscox_causal = pd.read_csv(result_path_cscox + '/cindex_causal.csv')
cscox_origin = pd.read_csv(result_path_cscox + '/cindex_origin.csv')

result_path_dsm = 'cindex_data/seer_dsm'
dsm_causal = pd.read_csv(result_path_dsm + '/cindex_causal.csv')
dsm_origin = pd.read_csv(result_path_dsm + '/cindex_origin.csv')

result_path_dh = 'cindex_data/seer_dh'
dh_causal = pd.read_csv(result_path_dh + '/cindex_causal.csv')
dh_origin = pd.read_csv(result_path_dh + '/cindex_origin.csv')


times = [1, 3, 5, 7]
fig = plt.figure(figsize=(45, 10))
fsize = 45
mksize = 18
lwidth = 4
num_event = 11

ymin = [0.7, 0.5, 0.5]

ymax = [0.8, 0.65, 0.65]

cindex_casual_fg = np.asarray(fg_causal)
cindex_origin_fg = np.asarray(fg_origin)

cindex_casual_cscox = np.asarray(cscox_causal)
cindex_origin_cscox = np.asarray(cscox_origin)

cindex_casual_dsm = np.asarray(dsm_causal)
cindex_origin_dsm = np.asarray(dsm_origin)

cindex_casual_dh = np.asarray(dh_causal)
cindex_origin_dh = np.asarray(dh_origin)


for ev in range(3):
    ax = fig.add_subplot(1, 4, ev + 1)
    # Plotting c-index result
    # colors
    # 3232b6
    # e35f34
    # de0800
    # 5b92d9
    # feaa11
    # f05066

    plt.plot(times, cindex_casual_fg[:, ev], label='Fine-Gray + Causal',
             color='#3232b6', lw=lwidth, marker='o', markersize=mksize)
    plt.plot(times, cindex_casual_cscox[:, ev], label='cs-Cox + Causal',
             color='#307724', lw=lwidth, marker='o', markersize=mksize)
    plt.plot(times, cindex_casual_dsm[:, ev], label='DSM + Causal',
             color='#8666c9', lw=lwidth, marker='o', markersize=mksize)
    plt.plot(times, cindex_casual_dh[:, ev], label='DeepHit + Causal',
             color='#e35f34', lw=lwidth, marker='o', markersize=mksize)

    plt.plot(times, cindex_origin_fg[:, ev], label='Fine-Gray',
             color='#5b92d9', lw=lwidth, marker='D', linestyle='--', markersize=mksize)
    plt.plot(times, cindex_origin_cscox[:, ev], label='cs-Cox',
             color='#6ea84e', lw=lwidth, marker='D', linestyle='--', markersize=mksize)
    plt.plot(times, cindex_origin_dsm[:, ev], label='DSM',
             color='#c45ca2', lw=lwidth, marker='D', linestyle='--', markersize=mksize)
    plt.plot(times, cindex_origin_dh[:, ev], label='DeepHit',
             color='#feaa11', lw=lwidth, marker='D', linestyle='--', markersize=mksize)

    # plt.plot(times, cindex_casual_ddh[:, ev], label='Dynamic-DeepHit + CI',
    #          color='#de0800', lw=4, marker='o', markersize=mksize)
    # plt.plot(times, cindex_origin_ddh[:, ev], label='Dynamic-DeepHit',
    #          color='#f05066', lw=4, marker='D', linestyle='--', markersize=mksize)

    plt.grid(linestyle='-.')
    plt.tick_params(labelsize=fsize)
    # if ev % 4 == 0:
    ax.set_xlabel('Time Horizon (year)', fontsize=fsize)
    ax.set_ylabel('C-Index C(t)', fontsize=fsize)
    ax.set_ylim([ymin[ev], ymax[ev]])
    ax.set_xlim([0, 8])
    plt.xticks(times)
    plt.title(titles_seer[ev], fontsize=45)
    plt.tight_layout(h_pad=5, w_pad=4)

plt.legend(fontsize=40, bbox_to_anchor=(1.3, 0.), loc=3,
           borderaxespad=0, ncol=1, frameon=False)
# plt.legend(fontsize=40, bbox_to_anchor=(-2.2, -0.6), loc=3,
#            borderaxespad=0, ncol=4, frameon=False)
plt.savefig('cindex_data/seer_cindex.png')
plt.show()
