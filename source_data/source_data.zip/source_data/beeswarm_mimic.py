import os.path

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import shap
from sklearn.model_selection import StratifiedKFold, train_test_split

import utils

titles_mimic = ['Septicemia/Sepsis', 'Cerebral Hemorrhage', 'Acute Respiratory Failure',
                'Myocardial Infarction', 'Heart Failure', 'Pneumonia', 'Cerebral Infarction',
                'Subarachnoid Hemorrhage', 'Neoplasm of Bronchus or Lung',
                'Cirrhosis of Liver', 'Acute Kidney Failure']

features_name = ['ca', 'leu', 'hepf', 'panc', 'vt', 'diab', 'gender', 'age', 'height', 'weight',
                 'bmi', 'heart_rate', 'sbp', 'dbp', 'mbp', 'fio2', 'resp_rate', 'temperature',
                 'spo2', 'hct', 'hgb', 'mch', 'mchc', 'mcv', 'platelet', 'rbc', 'rdw', 'wbc', 'pco2',
                 'po2', 'tco2', 'base_excess', 'aniongap', 'bicarbonate', 'bun', 'calcium',
                 'chloride', 'glucose', 'sodium', 'potassium', 'magnesium', 'phosphate',
                 'lactate', 'ph', 'inr', 'pt', 'ptt', 'alt', 'alp', 'ast', 'bil_total', 'nacl_09',
                 'dextrose', 'propofol', 'norepinephrine', 'gastric_med', 'insulin', 'gt_flush',
                 'fentanyl', 'kcl', 'heparin_sodium', 'vancomycin', 'furosemide',
                 'INDIAN', 'ASIAN', 'BLACK', 'HISPANIC/LATINO',
                 'ethnicity_OTHER', 'WHITE']

respath = 'shap_beeswarm_result/mimic'
if not os.path.exists(respath):
    os.makedirs(respath)

df_data = pd.read_csv('shap_data/mimic_fg/shap_data.csv')
shap_values_causal_all = np.load('shap_data/mimic_fg/shap_value_mimic_causal.npy')
shap_values_origin_all = np.load('shap_data/mimic_fg/shap_value_mimic.npy')

for ev in range(1, 12):
    shap_values_causal = shap_values_causal_all[:, :, ev - 1]
    shap_values_origin = shap_values_origin_all[:, :, ev - 1]
    shap_mean_abs = np.mean(np.abs(shap_values_causal), axis=0)
    order = np.argsort(-shap_mean_abs)
    cols = np.asarray(df_data.columns)
    col_order = cols[order]

    shap_values_causal_top = shap_values_causal[:, order]
    df_data_top = df_data[col_order]
    
    plt.cla()
    # plt.title(titles_mimic[ev - 1], fontsize=15)
    shap.summary_plot(shap_values_causal_top, df_data_top, max_display=100,
                      sort=False, show=False)
    plt.tight_layout(h_pad=5, w_pad=4)
    plt.savefig(respath + '/mimic_causal_ev{}.png'.format(ev))
    plt.show()

    shap_values_origin_top = shap_values_origin[:, order]
    df_data_top = df_data[col_order]

    plt.cla()
    plt.title(titles_mimic[ev - 1], fontsize=15)
    shap.summary_plot(shap_values_origin_top, df_data_top, max_display=100,
                      sort=False, show=False)
    plt.tight_layout(h_pad=5, w_pad=4)

    plt.savefig(respath + '/mimic_origin_ev{}.png'.format(ev))
    plt.show()

