import os

import numpy as np
import pandas as pd
from KMEstimate import *
import matplotlib.pyplot as plt
from sklearn.metrics import brier_score_loss
from utils import brier_score

title = {
    'dh': 'DeepHit',
    'fg': 'Fine-Gray',
    'cscox': 'cs-Cox',
    'ddh': 'Dynamic-DeepHit',
    'dsm': 'DSM'
}
model_names = ['fg', 'cscox', 'dsm', 'dh', 'ddh']

fig = plt.figure(figsize=(50, 10))

for order, model_name in enumerate(model_names):
    pred_risk_causal = np.load('calibration_data/eicu_{}/eicu_{}_causal.npy'.format(model_name, model_name))
    pred_risk_origin = np.load('calibration_data/eicu_{}/eicu_{}_origin.npy'.format(model_name, model_name))
    df = pd.read_csv('calibration_data/eicu_{}/true_label.csv'.format(model_name))
    true_time = np.asarray(df['true_time'])
    true_label = np.asarray(df['true_label'])
    ax_lim = [0., 0.6]
    true_label = np.cast['int32'](true_label > 0)

    eval_times = 20
    pred_risks_causal = []
    pred_risks_origin = []
    observed_risk_causal = []
    observed_risk_origin = []

    losses_causal = 0.
    losses_origin = 0.

    scaler = 0.1
    print('-----------------------------------------------------------')
    print('model:' + model_name)
    for i in range(5):
        idx_casual = np.where((pred_risk_causal >= scaler * i) & (pred_risk_causal < scaler * i + scaler))[0]
        idx_origin = np.where((pred_risk_origin >= scaler * i) & (pred_risk_origin < scaler * i + scaler))[0]
        if len(idx_casual) == 0 or len(idx_origin) == 0:
            continue
        strata_causal = pred_risk_causal[idx_casual]
        strata_origin = pred_risk_origin[idx_origin]
        km_causal = 1 - get_km_scores(true_time[idx_casual], true_label[idx_casual], fail_code=1)
        km_origin = 1 - get_km_scores(true_time[idx_origin], true_label[idx_origin], fail_code=1)

        observed_risk = km_causal[eval_times]
        observed_risk2 = km_origin[eval_times]
        losses_causal += abs(np.mean(strata_causal) - observed_risk)
        losses_origin += abs(np.mean(strata_origin) - observed_risk2)


        pred_risks_causal.append(np.mean(strata_causal))
        pred_risks_origin.append(np.mean(strata_origin))
        observed_risk_causal.append(observed_risk)
        observed_risk_origin.append(observed_risk2)

    losses_causal = losses_causal * 1. / len(observed_risk_causal)
    losses_origin = losses_origin * 1. / len(observed_risk_origin)

    ax = fig.add_subplot(1, 5, order + 1)
    plt.plot(pred_risks_causal, observed_risk_causal,
             label='{} + Causal({:.3f})'.format(title[model_name], losses_causal),
             color='#cb5362', lw=4, marker='o', markersize=12)
    plt.plot(pred_risks_origin, observed_risk_origin,
             label='{}({:.3f})'.format(title[model_name], losses_origin),
             color='#3fadaf', lw=4, marker='D', markersize=12)
    plt.plot((0, 1), (0, 1), ls='--', lw=3, color='gray')
    plt.tick_params(labelsize=30)

    ax.set_xlabel('Predicted Prob.', fontsize=35)
    ax.set_ylabel('Observed Prob.', fontsize=35)
    ax.set_ylim(ax_lim)
    ax.set_xlim(ax_lim)
    plt.legend(fontsize=25, loc='lower right')
    plt.tight_layout(h_pad=5, w_pad=4)

plt.savefig('calibration_result/eicu/calplot_eicu.png')
plt.show()









