import os

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import shap
from sklearn.model_selection import StratifiedKFold, train_test_split

import utils

columns = ['age', 'gender', 'income_level', 'grade',
                'rx_prim_site', 'cs_tumor_size', 'cs_extension', 'cs_lymph_nodes',
                'first_mailg', 'total_mailg', 'derived_ajcc_stage', 'nodes_examed',
                'nodes_positive', 'ethnicity_Black', 'ethnicity_White',
                'ethnicity_other', 'prim_site-Nipple',
                'prim_site-Central', 'prim_site-Upper-inner', 'prim_site-Lower-inner',
                'prim_site-Upper-outer', 'prim_site-Lower-outer', 'prim_site-Axillarytail',
                'prim_site-Overlapping', 'prim_site-NOS', 'laterality_Bilateral-single',
                'laterality_Left', 'laterality_one-side', 'laterality_Paired-site', 'laterality_Right',
                'hist_behavior_8480', 'hist_behavior_8500', 'hist_behavior_8520', 'hist_behavior_8522',
                'hist_behavior_8523', 'hist_behavior_other', 'cs_mets_at_dx_0', 'cs_mets_at_dx_5',
                'cs_mets_at_dx_10', 'cs_mets_at_dx_40', 'cs_mets_at_dx_42', 'cs_mets_at_dx_44',
                'cs_mets_at_dx_50', 'cs_mets_at_dx_60', 'summary_stage_Distant', 'summary_stage_Localized',
                'summary_stage_Regional']

titles_seer = ['Breast Cancer', 'Cardiovascular Disease', 'Cerebrovascular Disease']

respath = 'shap_beeswarm_result/seer'
if not os.path.exists(respath):
    os.makedirs(respath)

df_data = pd.read_csv('shap_data/seer_fg/shap_data.csv')

shap_values_causal_all = np.load('shap_data/seer_fg/shap_value_seer_causal.npy')
shap_values_origin_all = np.load('shap_data/seer_fg/shap_value_seer.npy')

for ev in range(1, 4):
    shap_values_causal = shap_values_causal_all[:, :, ev - 1]
    shap_values_origin = shap_values_origin_all[:, :, ev - 1]
    shap_mean_abs = np.mean(np.abs(shap_values_causal), axis=0)
    order = np.argsort(-shap_mean_abs)
    cols = np.asarray(df_data.columns)
    col_order = cols[order]
    print(col_order)

    shap_values_causal_top = shap_values_causal[:, order]
    df_data_top = df_data[col_order]

    plt.cla()
    plt.title(titles_seer[ev - 1], fontsize=15)
    shap.summary_plot(shap_values_causal_top, df_data_top, max_display=100,
                      sort=False, show=False)
    plt.tight_layout(h_pad=5, w_pad=4)
    plt.savefig(respath + '/seer_causal_ev{}.png'.format(ev))
    plt.show()

    shap_values_origin_top = shap_values_origin[:, order]
    df_data_top = df_data[col_order]

    plt.cla()
    plt.title(titles_seer[ev - 1], fontsize=15)
    shap.summary_plot(shap_values_origin_top, df_data_top, max_display=100,
                      sort=False, show=False)
    plt.tight_layout(h_pad=5, w_pad=4)

    plt.savefig(respath + '/seer_origin_ev{}.png'.format(ev))
    plt.show()
