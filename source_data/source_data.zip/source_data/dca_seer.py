import numpy as np
from utils import cal_net_benefit
import pandas as pd
import matplotlib.pyplot as plt


title = {
    'dh': 'DeepHit',
    'cscox': 'cs-Cox',
    'fg': 'Fine-Gray',
    'dsm': 'DSM'
}
model_name = 'dh'
titles_seer = ['Breast Cancer', 'Cardiovascular Disease', 'Cerebrovascular Disease']

dca_path = 'dca_data/seer_{}'.format(model_name)
risk_causal = np.load(dca_path + '/dca_causal.npy')
risk_origin = np.load(dca_path + '/dca_origin.npy')
true_labels = pd.read_csv('dca_data/seer_{}/true_label.csv'.format(model_name))

if model_name == 'fg':
    ymax = [
        0.1, 0.02, 0.005,
    ]
    ymin = [
        -0.01, -0.002, -0.001
    ]
    xmax = [
        0.6, 0.03, 0.01
    ]
    step = [0.01, 0.005, 0.001]
elif model_name == 'cscox':
    ymax = [
        0.08, 0.025, 0.006,
    ]
    ymin = [
        -0.01, -0.003, -0.001
    ]
    xmax = [
        0.6, 0.03, 0.01
    ]
    step = [0.01, 0.005, 0.001]
elif model_name == 'dsm':
    ymax = [
        0.08, 0.025, 0.006,
    ]
    ymin = [
        -0.01, -0.003, -0.001
    ]
    xmax = [
        0.6, 0.05, 0.02
    ]
    step = [0.05, 0.005, 0.002]
elif model_name == 'dh':
    ymax = [
        0.08, 0.01, 0.005,
    ]
    ymin = [
        -0.01, -0.002, -0.001
    ]
    xmax = [
        0.3, 0.1, 0.02
    ]
    step = [0.01, 0.005, 0.002]

else:
    ymax = [
        0.08, 0.01, 0.005,
    ]
    ymin = [
        -0.01, -0.002, -0.001
    ]
    xmax = [
        0.3, 0.1, 0.02
    ]
    step = [0.01, 0.005, 0.002]

time = np.asarray(true_labels['true_time'])
label = np.asarray(true_labels['true_label'])


fig = plt.figure(figsize=(45, 30))
for ev in range(3):
    label_ev = np.cast['int32'](label == ev + 1)
    print(ev + 1)
    thresholds = np.arange(0, xmax[ev] + step[ev], step[ev])
    net_benefit_causal = np.zeros([len(thresholds)])
    net_benefit_origin = np.zeros([len(thresholds)])
    net_benefit_alltreat = np.zeros([len(thresholds)])

    for i, thres in enumerate(thresholds):
        net_benefit_causal[i] = cal_net_benefit(time, label_ev, thres, risk_causal[:, ev], 60)
        net_benefit_origin[i] = cal_net_benefit(time, label_ev, thres, risk_origin[:, ev], 60)
        net_benefit_alltreat[i] = cal_net_benefit(time, label_ev, thres, np.ones(len(time)), 60)

    ax = fig.add_subplot(3, 4, ev + 1)
    plt.tick_params(labelsize=30)
    plt.plot(thresholds, net_benefit_alltreat, label='ALL',
             color='black', ls='--', lw=3)
    plt.plot(thresholds, np.zeros(len(thresholds)), ls='--', lw=3, color='gray', label='None')
    plt.plot(thresholds, net_benefit_causal, label='{} + Causal'.format(title[model_name]),
             color='#cb5362', lw=5)
    plt.plot(thresholds, net_benefit_origin, label='{}'.format(title[model_name]),
             color='#3fadaf', lw=5)

    ax.set_xlabel('Threshold Prob.', fontsize=35)
    ax.set_ylabel('Net Benefit', fontsize=35)
    ax.set_xlim(0, xmax[ev])
    ax.set_ylim(ymin[ev], ymax[ev])
    plt.title(titles_seer[ev], fontsize=45)

    plt.tight_layout(h_pad=5, w_pad=4)

plt.legend(fontsize=42, bbox_to_anchor=(1.2, 0), loc=3,
           borderaxespad=0, frameon=False)
plt.savefig('dca_data/dcaplot_seer_{}.png'.format(model_name))
plt.show()
