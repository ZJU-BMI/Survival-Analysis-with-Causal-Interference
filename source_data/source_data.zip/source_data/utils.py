import os

import numpy as np
import pandas as pd
from lifelines import KaplanMeierFitter
from scipy import stats

EPSILON = 1e-8


def get_num_eval(time, label, eval_time):
    num_eval = 0
    N = len(time)
    for i in range(N):
        # positive(died) at eval_time
        if time[i] <= eval_time and label[i] == 1:
            num_eval += 1
        # non-positive(survival) at eval_time
        elif time[i] > eval_time:
            num_eval += 1

    return num_eval


def get_tf_positive(time, label, threshold, pred_prob, eval_time):
    tp = fp = 0
    num_eval = 0
    N = len(pred_prob)
    for i in range(N):
        # positive(died) at eval_time
        if time[i] <= eval_time and label[i] == 1:
            num_eval += 1
            if pred_prob[i] >= threshold:
                tp += 1
        # non-positive(survival) at eval_time
        elif time[i] > eval_time:
            num_eval += 1
            if pred_prob[i] >= threshold:
                fp += 1
    return tp, fp, num_eval


def cal_net_benefit(time, label, threshold, pred_prob, eval_time):
    if threshold == 0:
        threshold = 1e-8
    elif threshold == 1:
        threshold = 1. - 1e-8
    time = np.reshape(time, [-1])
    label = np.reshape(label, [-1])
    tp, fp, num_eval = get_tf_positive(time, label, threshold, pred_prob, eval_time=eval_time)
    if num_eval == 0:
        raise ValueError('Can not calculate net benefit')
    theta = threshold / (1 - threshold)
    res = tp * 1. / num_eval - fp * 1. / num_eval * theta
    return res


def mean_interval(mean=None, std=None, sig=None, n=None, confidence=0.95):
    alpha = 1 - confidence
    z_score = stats.norm.isf(alpha / 2)  
    t_score = stats.t.isf(alpha / 2, df=(n - 1))  
    lower_limit = mean
    upper_limit = mean

    if n >= 30 and sig is not None:
        me = z_score * sig / np.sqrt(n)
        lower_limit = mean - me
        upper_limit = mean + me

    if n >= 30 and sig is None:
        me = z_score * std / np.sqrt(n)
        lower_limit = mean - me
        upper_limit = mean + me

    if n < 30 and sig is None:
        me = t_score * std / np.sqrt(n)
        lower_limit = mean - me
        upper_limit = mean + me

    return lower_limit, upper_limit
