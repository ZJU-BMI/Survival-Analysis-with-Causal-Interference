import os.path
import numpy as np
from utils import cal_net_benefit
import pandas as pd
import matplotlib.pyplot as plt

title = {
    'dh': 'DeepHit',
    'cscox': 'cs-Cox',
    'fg': 'Fine-Gray',
    'dsm': 'DSM',
    'ddh': 'Dynamic-DeepHit'
}
model_name = 'fg'
titles_mimic = ['Septicemia/Sepsis', 'Neoplasm', 'Cerebral Hemorrhage', 'Acute Respiratory Failure',
                'Myocardial Infarction', 'Heart Failure', 'Pneumonia', 'Cerebral Infarction',
                'Subarachnoid Hemorrhage', 'Cirrhosis of Liver', 'Acute Kidney Failure', 'Total']

dca_path = 'dca_data/mimic_{}'.format(model_name)
risk_causal = np.load(dca_path + '/dca_causal.npy')
risk_origin = np.load(dca_path + '/dca_origin.npy')
true_labels = pd.read_csv('dca_data/mimic_{}/true_label.csv'.format(model_name))

time = np.asarray(true_labels['true_time'])
label = np.asarray(true_labels['true_label'])

fig = plt.figure(figsize=(45, 30))

thesmax = [30, 12, 12, 18, 18, 18, 6, 12, 12, 12, 6]
step = [5, 2, 2, 3, 3, 3, 1, 2, 2, 2, 1]
for ev in range(11):
    label_ev = np.cast['int32'](label == ev + 1)
    thresholds = np.arange(step[ev], thesmax[ev] + 1, step[ev]) / 100
    net_benefit_causal = np.zeros([len(thresholds)])
    net_benefit_origin = np.zeros([len(thresholds)])
    net_benefit_alltreat = np.zeros([len(thresholds)])

    for i, thres in enumerate(thresholds):
        net_benefit_causal[i] = cal_net_benefit(time, label_ev, thres, risk_causal[:, ev], 5)
        net_benefit_origin[i] = cal_net_benefit(time, label_ev, thres, risk_origin[:, ev], 5)
        net_benefit_alltreat[i] = cal_net_benefit(time, label_ev, thres, np.ones(len(time)), 5)

    print("event: {}".format(titles_mimic[ev]))
    print('---------------------------------------------------------------------------')
    res_path = 'dca_result/mimic_net_benefit_{}/'.format(model_name)
    if not os.path.exists(res_path):
        os.makedirs(res_path)
    res_df = pd.DataFrame({
        'threshold': thresholds,
        'nb_origin': np.round(net_benefit_origin * 100, 2),
        'nb_causal': np.round(net_benefit_causal * 100, 2),
        'nb_origin_all': np.round((net_benefit_origin - net_benefit_alltreat) * 100, 2),
        'nb_casual_all': np.round((net_benefit_causal - net_benefit_alltreat) * 100, 2)
    })
    res_df.to_csv(res_path + '/net_benefit_mimic_ev{}.csv'.format(ev + 1), index=False)