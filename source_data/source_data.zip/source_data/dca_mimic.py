import os.path

import numpy as np
from utils import cal_net_benefit
import pandas as pd
import matplotlib.pyplot as plt


title = {
    'dh': 'DeepHit',
    'cscox': 'cs-Cox',
    'fg': 'Fine-Gray',
    'ddh': 'Dynamic-DeepHit',
    'dsm': 'DSM'
}
model_name = 'fg'
titles_mimic = ['Septicemia/Sepsis', 'Cerebral Hemorrhage', 'Acute Respiratory Failure',
                'Myocardial Infarction', 'Heart Failure', 'Pneumonia', 'Cerebral Infarction',
                'Subarachnoid Hemorrhage', 'Neoplasm of Bronchus or Lung',
                'Cirrhosis of Liver', 'Acute Kidney Failure']

dca_path = 'dca_data/mimic_{}'.format(model_name)
risk_causal = np.load(dca_path + '/dca_causal.npy')
risk_origin = np.load(dca_path + '/dca_origin.npy')
true_labels = pd.read_csv('dca_data/mimic_{}/true_label.csv'.format(model_name))

if model_name == 'fg':
    ymax = [
        0.1, 0.01, 0.01, 0.015,
        0.01, 0.005, 0.005, 0.005,
        0.005, 0.006, 0.002
    ]
    ymin = [
        -0.01, -0.002, -0.001, -0.001,
        -0.001, -0.001, -0.001, -0.0005,
        -0.001, -0.001, -0.0002,
    ]
    xmax = [
        1, 0.2, 0.4, 0.65,
        0.4, 0.15, 0.15, 0.2,
        0.4, 0.2, 0.1
    ]
elif model_name == 'cscox':
    ymax = [
        0.1, 0.01, 0.01, 0.015,
        0.01, 0.005, 0.005, 0.005,
        0.005, 0.005, 0.002
    ]
    ymin = [
        -0.01, -0.001, -0.001, -0.001,
        -0.001, -0.001, -0.001, -0.0005,
        -0.001, -0.0005, -0.0002,
    ]
    xmax = [
        1, 0.2, 0.3, 0.65,
        0.4, 0.2, 0.15, 0.2,
        0.4, 0.3, 0.1
    ]
elif model_name == 'dsm':
    ymax = [
        0.08, 0.008, 0.01, 0.015,
        0.01, 0.005, 0.008, 0.005,
        0.0065, 0.005, 0.002
    ]
    ymin = [
        -0.01, -0.001, -0.001, -0.001,
        -0.001, -0.001, -0.001, -0.0005,
        -0.001, -0.0005, -0.0004,
    ]
    xmax = [
        0.6, 0.2, 0.2, 0.4,
        0.3, 0.15, 0.15, 0.2,
        0.15, 0.25, 0.1
    ]
elif model_name == 'dh':
    ymax = [
        0.1, 0.01, 0.01, 0.015,
        0.01, 0.005, 0.008, 0.005,
        0.005, 0.005, 0.002
    ]
    ymin = [
        -0.01, -0.001, -0.001, -0.001,
        -0.001, -0.001, -0.001, -0.0005,
        -0.001, -0.0005, -0.0002,
    ]
    xmax = [
        1, 0.2, 0.3, 0.65,
        0.4, 0.2, 0.15, 0.15,
        0.4, 0.3, 0.1
    ]
elif model_name == 'ddh':
    ymax = [
        0.1, 0.01, 0.01, 0.015,
        0.01, 0.005, 0.008, 0.005,
        0.007, 0.006, 0.002
    ]
    ymin = [
        -0.01, -0.001, -0.001, -0.001,
        -0.001, -0.001, -0.001, -0.0005,
        -0.001, -0.001, -0.0002,
    ]
    xmax = [
        1, 0.3, 0.20, 0.45,
        0.3, 0.2, 0.10, 0.35,
        0.3, 0.3, 0.1
    ]
else:
    ymax = [
        0.1, 0.01, 0.01, 0.015,
        0.01, 0.005, 0.008, 0.005,
        0.005, 0.005, 0.002
    ]
    ymin = [
        -0.01, -0.001, -0.001, -0.001,
        -0.001, -0.001, -0.001, -0.0005,
        -0.001, -0.001, -0.0002,
    ]
    xmax = [
        1, 0.3, 0.25, 0.45,
        0.3, 0.2, 0.15, 0.25,
        0.3, 0.3, 0.1
    ]

time = np.asarray(true_labels['true_time'])
label = np.asarray(true_labels['true_label'])


fig = plt.figure(figsize=(45, 30))

for ev in range(11):
    label_ev = np.cast['int32'](label == ev + 1)
    thresholds = np.arange(0, xmax[ev] + 0.01, 0.01)
    net_benefit_causal = np.zeros([len(thresholds)])
    net_benefit_origin = np.zeros([len(thresholds)])
    net_benefit_alltreat = np.zeros([len(thresholds)])

    for i, thres in enumerate(thresholds):
        net_benefit_causal[i] = cal_net_benefit(time, label_ev, thres, risk_causal[:, ev], 5)
        net_benefit_origin[i] = cal_net_benefit(time, label_ev, thres, risk_origin[:, ev], 5)
        net_benefit_alltreat[i] = cal_net_benefit(time, label_ev, thres, np.ones(len(time)), 5)

    ax = fig.add_subplot(3, 4, ev + 1)
    # ax = fig.add_subplot(111)
    plt.tick_params(labelsize=30)
    plt.plot(thresholds, net_benefit_alltreat, label='ALL',
             color='black', ls='--', lw=3)
    plt.plot(thresholds, np.zeros(len(thresholds)), ls='--', lw=3, color='gray', label='None')
    plt.plot(thresholds, net_benefit_causal, label='{} + Causal'.format(title[model_name]),
             color='#cb5362', lw=5)
    plt.plot(thresholds, net_benefit_origin, label='{}'.format(title[model_name]),
             color='#3fadaf', lw=5)

    ax.set_xlabel('Threshold Prob.', fontsize=35)
    ax.set_ylabel('Net Benefit', fontsize=35)
    ax.set_xlim(0, xmax[ev])
    ax.set_ylim(ymin[ev], ymax[ev])
    plt.title(titles_mimic[ev], fontsize=45)

    plt.tight_layout(h_pad=5, w_pad=4)

plt.legend(fontsize=42, bbox_to_anchor=(1.2, 0), loc=3,
           borderaxespad=0, frameon=False)
plt.savefig('dca_data/dcaplot_mimic_{}_test.png'.format(model_name))
plt.show()
