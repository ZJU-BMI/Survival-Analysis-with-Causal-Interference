import numpy as np
import pandas as pd
from KMEstimate import *
import matplotlib.pyplot as plt

titles_eicu = ['Cardiac Arrest', 'Sepsis', 'Acute Respiratory Failure', 'Septic Shock',
               'Stroke', 'Pneumonia', 'GI Bleeding', 'Heart Failure',
               'Acute Respiratory Distress', 'Myocardial Infarction',
               'Acute Renal Failure', 'Total']

result_path_fg = 'cindex_data/eicu_fg'
fg_causal = pd.read_csv(result_path_fg + '/cindex_causal.csv')
fg_origin = pd.read_csv(result_path_fg + '/cindex_origin.csv')


result_path_cscox = 'cindex_data/eicu_cscox'
cscox_causal = pd.read_csv(result_path_cscox + '/cindex_causal.csv')
cscox_origin = pd.read_csv(result_path_cscox + '/cindex_origin.csv')

result_path_dsm = 'cindex_data/eicu_dsm'
dsm_causal = pd.read_csv(result_path_dsm + '/cindex_causal.csv')
dsm_origin = pd.read_csv(result_path_dsm + '/cindex_origin.csv')

result_path_dh = 'cindex_data/eicu_dh'
dh_causal = pd.read_csv(result_path_dh + '/cindex_causal.csv')
dh_origin = pd.read_csv(result_path_dh + '/cindex_origin.csv')

result_path_ddh = 'cindex_data/eicu_ddh'
ddh_causal = pd.read_csv(result_path_ddh + '/cindex_causal.csv')
ddh_origin = pd.read_csv(result_path_ddh + '/cindex_origin.csv')


times = [5, 10, 15, 20]
fig = plt.figure(figsize=(42, 30))
fsize = 45
mksize = 18
lwidth = 4
num_event = 11

ymin = [0.85, 0.6, 0.5, 0.65,
        0.5, 0.5, 0.65, 0.5,
        0.5, 0.5, 0.65, 0.6]

ymax = [1, 1, 0.85, 1,
        1.0, 0.9, 1.0, 1.0,
        1, 1.0, 1, 0.95]

cindex_casual_fg = np.asarray(fg_causal)
cindex_origin_fg = np.asarray(fg_origin)

cindex_casual_cscox = np.asarray(cscox_causal)
cindex_origin_cscox = np.asarray(cscox_origin)

cindex_casual_dsm = np.asarray(dsm_causal)
cindex_origin_dsm = np.asarray(dsm_origin)

cindex_casual_dh = np.asarray(dh_causal)
cindex_origin_dh = np.asarray(dh_origin)

cindex_casual_ddh = np.asarray(ddh_causal)
cindex_origin_ddh = np.asarray(ddh_origin)

for ev in range(11):
    ax = fig.add_subplot(3, 4, ev + 1)
    # Plotting c-index result
    # colors
    # 3232b6
    # e35f34
    # de0800
    # 5b92d9
    # feaa11
    # f05066

    plt.plot(times, cindex_casual_fg[:, ev], label='Fine-Gray + Causal',
             color='#3232b6', lw=lwidth, marker='o', markersize=mksize)

    plt.plot(times, cindex_casual_cscox[:, ev], label='cs-Cox + Causal',
             color='#307724', lw=lwidth, marker='o', markersize=mksize)

    plt.plot(times, cindex_casual_dsm[:, ev], label='DSM + Causal',
             color='#8666c9', lw=lwidth, marker='o', markersize=mksize)

    plt.plot(times, cindex_casual_dh[:, ev], label='DeepHit + Causal',
             color='#e35f34', lw=lwidth, marker='o', markersize=mksize)

    plt.plot(times, cindex_casual_ddh[:, ev], label='Dynamic-DeepHit + Causal',
             color='#de0800', lw=4, marker='o', markersize=mksize)

    plt.plot(times, cindex_origin_fg[:, ev], label='Fine-Gray',
             color='#5b92d9', lw=lwidth, marker='D', linestyle='--', markersize=mksize)

    plt.plot(times, cindex_origin_cscox[:, ev], label='cs-Cox',
             color='#6ea84e', lw=lwidth, marker='D', linestyle='--', markersize=mksize)

    plt.plot(times, cindex_origin_dsm[:, ev], label='DSM',
             color='#c45ca2', lw=lwidth, marker='D', linestyle='--', markersize=mksize)

    plt.plot(times, cindex_origin_dh[:, ev], label='DeepHit',
             color='#feaa11', lw=lwidth, marker='D', linestyle='--', markersize=mksize)

    plt.plot(times, cindex_origin_ddh[:, ev], label='Dynamic-DeepHit',
             color='#f05066', lw=lwidth, marker='D', linestyle='--', markersize=mksize)

    plt.grid(linestyle='-.')
    plt.tick_params(labelsize=fsize)
    # if ev % 4 == 0:
    ax.set_xlabel('Time Horizon (days)', fontsize=fsize)
    ax.set_ylabel('C-Index C(t)', fontsize=fsize)
    ax.set_ylim([ymin[ev], ymax[ev]])
    ax.set_xlim([4, 21])
    plt.xticks(times)

    plt.title(titles_eicu[ev], fontsize=45)
    plt.tight_layout(h_pad=5, w_pad=4)

plt.legend(fontsize=35, bbox_to_anchor=(1.3, 0.), loc=3,
           borderaxespad=0, ncol=1, frameon=False)
# plt.legend(fontsize=45, bbox_to_anchor=(-2.4, -0.5), loc=3,
#            borderaxespad=0, ncol=3, frameon=False)
plt.savefig('cindex_data/eicu_cindex.png')
plt.show()
