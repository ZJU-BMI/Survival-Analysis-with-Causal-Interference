import os

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import shap


titles_eicu = ['Cardiac Arrest', 'Sepsis', 'Acute Respiratory Failure', 'Septic Shock',
               'Stroke', 'Pneumonia', 'GI Bleeding', 'Heart Failure',
               'Acute Respiratory Distress', 'Myocardial Infarction', 'Acute Renal Failure']

features_name = ['ra', 'respa', 'suhe', 'copd', 'vt', 'pe', 'age', 'gender', 'weight', 'height',
                 'bmi', 'heart_rate', 'resp_rate', 'sao2', 'sbp', 'dbp', 'mbp', 'temperature',
                 'gcs_total', 'hgb', 'hct', 'mch', 'mchc', 'mcv', 'mpv', 'platelets', 'rbc', 'rdw',
                 'wbc', 'lymp', 'mono', 'albumin', 'total_protein', 'aniongap', 'bicarbonate',
                 'bun', 'calcium', 'chloride', 'creatinine', 'glucose', 'sodium', 'potassium',
                 'magnesium', 'alt', 'bil_total', 'AfricanAmerican','Asian', 'Caucasian', 'Hispanic',
                 'NativeAmerican', 'ethnicity_OTHER']

respath = 'shap_beeswarm_result/eicu'
if not os.path.exists(respath):
    os.makedirs(respath)

df_data = pd.read_csv('shap_data/eicu_fg/shap_data.csv')

data_path_causal = 'shap_data/eicu_fg/shap_value_eicu_causal.npy'
shap_values_causal_all = np.load(data_path_causal)
data_path_origin = 'shap_data/eicu_fg/shap_value_eicu.npy'
shap_values_origin_all = np.load(data_path_origin)

for ev in range(1, 12):
    shap_values_causal = shap_values_causal_all[:, :, ev - 1]
    shap_values_origin = shap_values_origin_all[:, :, ev - 1]
    shap_mean_abs = np.mean(np.abs(shap_values_causal), axis=0)

    order = np.argsort(-shap_mean_abs)
    cols = np.asarray(df_data.columns)
    col_order = cols[order]
    print(col_order)

    shap_values_causal_top = shap_values_causal[:, order]

    df_data_top = df_data[col_order]

    plt.cla()
    plt.title(titles_eicu[ev - 1], fontsize=15)
    shap.summary_plot(shap_values_causal_top, df_data_top, max_display=100, sort=False, show=False)
    plt.tight_layout(h_pad=5, w_pad=4) 
    plt.savefig(respath + '/eicu_causal_ev{}'.format(ev))
    plt.show()

    shap_values_origin_top = shap_values_origin[:, order]
    df_data_top = df_data[col_order]

    plt.cla()
    plt.title(titles_eicu[ev - 1], fontsize=15)
    shap.summary_plot(shap_values_origin_top, df_data_top, max_display=100, sort=False, show=False)
    plt.tight_layout(h_pad=5, w_pad=4) 
    plt.savefig(respath + '/eicu_origin_ev{}'.format(ev))
    plt.show()



